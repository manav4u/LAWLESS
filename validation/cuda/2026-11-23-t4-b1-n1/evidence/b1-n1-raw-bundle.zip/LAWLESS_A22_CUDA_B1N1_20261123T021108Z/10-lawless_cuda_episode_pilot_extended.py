
#!/usr/bin/env python3
"""Bounded B1/N1 CUDA episode pilot for the pinned LAWLESS checkout."""

from __future__ import annotations

import argparse
import base64
import dataclasses
import datetime as dt
import hashlib
import inspect
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
import zipfile


EXPECTED_ROOT = Path("/content/LAWLESS_cuda_smoke_0a6b409e9433")
EXPECTED_COMMIT = "0a6b409e9433a428cb6b34e02f0cd96c7cb85b6a"

BATCH = 1
CANDIDATES = 1
SEED = 7
TRANSITIONS = 2400
CHILD_LIMIT_SECONDS = 420
PARENT_LIMIT_SECONDS = 450
CHECKPOINT_EVERY = 50


def utc_stamp():
    return dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def json_write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, sort_keys=True, default=str) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def git(root, *args):
    result = subprocess.run(
        ["git", *args],
        cwd=str(root),
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode:
        raise RuntimeError(
            f"git {' '.join(args)} failed ({result.returncode}): "
            f"{result.stderr.strip()}"
        )
    return result.stdout.strip()


def git_guard(root):
    root = Path(root).resolve()
    if not root.is_dir():
        raise RuntimeError(f"Checkout does not exist: {root}")

    head = git(root, "rev-parse", "HEAD")
    status = git(root, "status", "--porcelain", "--untracked-files=all")

    result = {
        "root": str(root),
        "head": head,
        "expected_commit": EXPECTED_COMMIT,
        "working_tree_clean": status == "",
        "status_porcelain": status,
    }

    if head != EXPECTED_COMMIT:
        raise RuntimeError(
            f"Wrong checkout HEAD: expected {EXPECTED_COMMIT}, got {head}"
        )
    if status:
        raise RuntimeError("Pinned checkout is not clean")

    return result


def is_inside(path, root):
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except (ValueError, OSError, TypeError):
        return False


def child_main(root, receipt_path):
    receipt_path = Path(receipt_path).resolve()
    root = Path(root).resolve()

    receipt = {
        "pilot": "LAWLESS_A22_CUDA_B1N1",
        "status": "running",
        "measurement_type": "instrumented_correctness_pilot",
        "root": str(root),
        "expected_commit": EXPECTED_COMMIT,
        "batch": BATCH,
        "candidates": CANDIDATES,
        "seed": SEED,
        "requested_transitions": TRANSITIONS,
        "completed_transitions": 0,
        "checkpoint_interval": CHECKPOINT_EVERY,
        "child_limit_seconds": CHILD_LIMIT_SECONDS,
        "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
    }

    def save():
        receipt["updated_utc"] = dt.datetime.now(
            dt.timezone.utc
        ).isoformat()
        json_write(receipt_path, receipt)

    class PilotDeadline(Exception):
        pass

    try:
        # This process is launched with the pinned checkout as cwd and
        # PYTHONPATH. Recheck before importing project code.
        receipt["git_before"] = git_guard(root)

        if str(root) not in sys.path:
            sys.path.insert(0, str(root))

        import torch
        from benchmarks import environment_benchmark as a21
        import lawless.sensors.lidar as lidar_module
        import lawless.sensors.observations as observations_module

        receipt["python"] = sys.version
        receipt["torch_version"] = torch.__version__

        benchmark_path = Path(a21.__file__).resolve()
        if benchmark_path != (
            root / "benchmarks" / "environment_benchmark.py"
        ).resolve():
            raise RuntimeError(
                f"Unexpected benchmark import: {benchmark_path}"
            )

        import_paths = {
            "benchmark": str(benchmark_path),
            "reset": inspect.getsourcefile(a21.reset),
            "step": inspect.getsourcefile(a21.step),
            "lidar": inspect.getsourcefile(lidar_module.sense_lidar),
            "observations": inspect.getsourcefile(
                observations_module.assemble_observations
            ),
        }

        for name, path in import_paths.items():
            if not path or not is_inside(path, root):
                raise RuntimeError(
                    f"{name} import is outside pinned checkout: {path}"
                )

        receipt["import_paths"] = import_paths

        # Capture A1's full source identity, including its frozen P0
        # inventory, before executing the workload.
        source_before = a21.source_identity(root)
        receipt["source_identity_before"] = a21.json_safe(source_before)

        if source_before.get("status") != "verified":
            raise RuntimeError(
                "A1 source identity did not report status=verified"
            )

        device = torch.device("cuda:0")
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA is unavailable in this runtime")

        torch.cuda.init()
        receipt["runtime"] = a21.json_safe(
            a21.runtime_metadata(device)
        )
        receipt["device_name"] = torch.cuda.get_device_name(device)
        receipt["cuda_device"] = str(device)

        # Record memory baseline before reset, then track peaks over the
        # reset and complete public-step episode.
        receipt["cuda_memory_before"] = {
            "allocated_bytes": torch.cuda.memory_allocated(device),
            "reserved_bytes": torch.cuda.memory_reserved(device),
        }
        torch.cuda.reset_peak_memory_stats(device)

        config = a21.create_a21_config(seed=SEED)
        receipt["config"] = a21.json_safe(config)

        torch.cuda.synchronize(device)
        reset_start = time.perf_counter()

        reset_result = a21.reset(
            config,
            BATCH,
            CANDIDATES,
            device=device,
            dtype=torch.float32,
        )

        torch.cuda.synchronize(device)
        reset_end = time.perf_counter()

        receipt["reset_seconds"] = reset_end - reset_start

        if not isinstance(reset_result, tuple) or len(reset_result) != 3:
            raise RuntimeError(
                "A1 reset must return "
                "(environment, observations, reset_info)"
            )

        environment, observations, reset_info = reset_result
        receipt["reset_info"] = a21.json_safe(reset_info)

        if not isinstance(observations, torch.Tensor):
            raise TypeError("Reset observations are not a tensor")
        if tuple(observations.shape) != (BATCH, CANDIDATES, 23):
            raise RuntimeError(
                f"Unexpected reset observation shape: "
                f"{tuple(observations.shape)}"
            )
        if observations.device != device:
            raise RuntimeError(
                f"Reset observations are on {observations.device}, "
                f"expected {device}"
            )
        if observations.dtype != torch.float32:
            raise RuntimeError(
                f"Unexpected reset observation dtype: {observations.dtype}"
            )
        if not torch.isfinite(observations).all().item():
            raise RuntimeError("Reset observations contain non-finite values")

        # Capture the same fixed controller targets used by A2.2.
        if not hasattr(environment, "worlds") or not environment.worlds:
            raise RuntimeError("Reset returned an environment with no worlds")

        target_positions = torch.stack(
            [
                world.episode.physics.position
                for world in environment.worlds
            ],
            dim=0,
        ).detach().clone()

        if tuple(target_positions.shape) != (BATCH, CANDIDATES, 2):
            raise RuntimeError(
                f"Unexpected target-position shape: "
                f"{tuple(target_positions.shape)}"
            )
        if target_positions.device != device:
            raise RuntimeError("Controller targets are not on CUDA")
        if not torch.isfinite(target_positions).all().item():
            raise RuntimeError("Controller targets contain non-finite values")

        # Walk all reachable LAWLESS state objects and record every tensor
        # field. Aliased tensor fields are recorded under each field path.
        def tensor_inventory(value):
            records = []
            visited = set()
            node_count = 0

            def walk(obj, path, depth=0):
                nonlocal node_count
                node_count += 1
                if node_count > 100000:
                    raise RuntimeError("State traversal exceeded node limit")
                if depth > 30:
                    raise RuntimeError("State traversal exceeded depth limit")

                if isinstance(obj, torch.Tensor):
                    finite = None
                    if obj.is_floating_point() or obj.is_complex():
                        finite = bool(torch.isfinite(obj).all().item())

                    records.append({
                        "path": path,
                        "shape": list(obj.shape),
                        "dtype": str(obj.dtype),
                        "device": str(obj.device),
                        "layout": str(obj.layout),
                        "requires_grad": bool(obj.requires_grad),
                        "finite": finite,
                    })
                    if finite is False:
                        raise RuntimeError(
                            f"Non-finite tensor in environment: {path}"
                        )
                    return

                if obj is None or isinstance(
                    obj, (str, bytes, int, float, bool, torch.dtype,
                          torch.device, Path)
                ):
                    return

                if isinstance(obj, (dict, list, tuple)):
                    identity = id(obj)
                    if identity in visited:
                        return
                    visited.add(identity)

                    if isinstance(obj, dict):
                        for key, item in obj.items():
                            walk(item, f"{path}[{key!r}]", depth + 1)
                    else:
                        for index, item in enumerate(obj):
                            walk(item, f"{path}[{index}]", depth + 1)
                    return

                if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
                    identity = id(obj)
                    if identity in visited:
                        return
                    visited.add(identity)
                    for field in dataclasses.fields(obj):
                        walk(
                            getattr(obj, field.name),
                            f"{path}.{field.name}",
                            depth + 1,
                        )
                    return

                # Restrict object traversal to project-owned objects.
                module_name = type(obj).__module__
                if module_name.startswith("lawless."):
                    identity = id(obj)
                    if identity in visited:
                        return
                    visited.add(identity)
                    for name, item in vars(obj).items():
                        walk(item, f"{path}.{name}", depth + 1)

            walk(value, "environment")
            return records

        receipt["initial_tensor_inventory"] = tensor_inventory(environment)
        receipt["initial_tensor_count"] = len(
            receipt["initial_tensor_inventory"]
        )
        receipt["initial_non_cuda_tensor_fields"] = [
            item["path"]
            for item in receipt["initial_tensor_inventory"]
            if item["device"] != str(device)
        ]
        if receipt["initial_non_cuda_tensor_fields"]:
            raise RuntimeError(
                "Initial environment contains non-CUDA tensor fields: "
                + ", ".join(receipt["initial_non_cuda_tensor_fields"])
            )
        save()

        # One bounded, non-repeated episode. CUDA synchronization brackets
        # the measured public-step loop.
        torch.cuda.synchronize(device)
        episode_start = time.perf_counter()
        deadline = time.monotonic() + CHILD_LIMIT_SECONDS

        for transition in range(TRANSITIONS):
            if time.monotonic() >= deadline:
                raise PilotDeadline(
                    f"Child deadline reached after "
                    f"{transition} transitions"
                )

            actions = a21.a21_controller_actions(
                environment,
                target_positions,
            )

            if not isinstance(actions, torch.Tensor):
                raise TypeError("Controller actions are not a tensor")
            if tuple(actions.shape) != (BATCH, CANDIDATES, 2):
                raise RuntimeError(
                    f"Unexpected action shape: {tuple(actions.shape)}"
                )
            if actions.device != device or actions.dtype != torch.float32:
                raise RuntimeError(
                    "Controller actions have unexpected device or dtype"
                )
            if not torch.isfinite(actions).all().item():
                raise RuntimeError("Controller actions are non-finite")

            step_result = a21.step(environment, actions)
            if not isinstance(step_result, tuple) or len(step_result) != 6:
                raise RuntimeError(
                    "Public step must return six values"
                )

            (
                environment,
                observations,
                rewards,
                terminated,
                truncated,
                info,
            ) = step_result

            if not isinstance(rewards, torch.Tensor):
                raise TypeError("Step rewards are not a tensor")
            if tuple(rewards.shape) != (BATCH, CANDIDATES):
                raise RuntimeError(
                    f"Unexpected reward shape: {tuple(rewards.shape)}"
                )
            if rewards.device != device or rewards.dtype != torch.float32:
                raise RuntimeError(
                    "Step rewards must be float32 on CUDA"
                )
            if not torch.isfinite(rewards).all().item():
                raise RuntimeError("Step rewards contain non-finite values")

            for mask_name, mask in (
                ("terminated", terminated),
                ("truncated", truncated),
            ):
                if not isinstance(mask, torch.Tensor):
                    raise TypeError(f"Step {mask_name} is not a tensor")
                if tuple(mask.shape) != (BATCH, CANDIDATES):
                    raise RuntimeError(
                        f"Unexpected {mask_name} shape: {tuple(mask.shape)}"
                    )
                if mask.device != device or mask.dtype != torch.bool:
                    raise RuntimeError(
                        f"Step {mask_name} must be bool on CUDA"
                    )

            if not isinstance(observations, torch.Tensor):
                raise TypeError(
                    f"Step {transition + 1}: observations are not a tensor"
                )
            if tuple(observations.shape) != (BATCH, CANDIDATES, 23):
                raise RuntimeError(
                    f"Step {transition + 1}: unexpected observation shape "
                    f"{tuple(observations.shape)}"
                )
            if observations.device != device:
                raise RuntimeError(
                    f"Step {transition + 1}: observations left CUDA"
                )
            if observations.dtype != torch.float32:
                raise RuntimeError(
                    f"Step {transition + 1}: unexpected observation dtype"
                )

            receipt["completed_transitions"] = transition + 1

            if (transition + 1) % CHECKPOINT_EVERY == 0:
                torch.cuda.synchronize(device)
                checkpoint_time = time.perf_counter()

                receipt["elapsed_loop_seconds"] = (
                    checkpoint_time - episode_start
                )
                receipt["episode_seconds"] = (
                    checkpoint_time - episode_start
                )
                receipt["checkpoint_per_world_steps"] = a21.json_safe(
                    a21.per_world_steps(environment)
                )
                receipt["checkpoint_per_world_completed"] = a21.json_safe(
                    a21.per_world_completed(environment)
                )
                receipt["checkpoint_final_inventory"] = a21.json_safe(
                    a21.final_inventory(environment)
                )
                save()

        torch.cuda.synchronize(device)
        episode_end = time.perf_counter()

        receipt["episode_seconds"] = episode_end - episode_start
        receipt["seconds_per_transition"] = (
            receipt["episode_seconds"] / TRANSITIONS
        )

        if not torch.isfinite(observations).all().item():
            raise RuntimeError("Final observations contain non-finite values")

        # Final state inventory and A1 state counters are deliberately
        # collected outside the timed loop.
        receipt["final_tensor_inventory"] = tensor_inventory(environment)
        receipt["final_tensor_count"] = len(
            receipt["final_tensor_inventory"]
        )
        receipt["final_non_cuda_tensor_fields"] = [
            item["path"]
            for item in receipt["final_tensor_inventory"]
            if item["device"] != str(device)
        ]

        receipt["final_inventory"] = a21.json_safe(
            a21.final_inventory(environment)
        )
        receipt["per_world_steps"] = a21.json_safe(
            a21.per_world_steps(environment)
        )
        receipt["per_world_completed"] = a21.json_safe(
            a21.per_world_completed(environment)
        )

        step_counts = torch.as_tensor(
            a21.per_world_steps(environment)
        ).reshape(-1).tolist()
        receipt["step_counts_flat"] = step_counts

        if receipt["final_non_cuda_tensor_fields"]:
            raise RuntimeError(
                "Final environment contains non-CUDA tensor fields: "
                + ", ".join(receipt["final_non_cuda_tensor_fields"])
            )

        final = receipt["final_inventory"]

        expected_final = {
            "world_completed": [True],
            "worlds_completed": 1,
            "worlds_total": 1,
            "world_step_counts": [TRANSITIONS],
            "physical_alive_per_world": [1],
            "extracted_per_world": [0],
            "failed_per_world": [0],
            "truncated_per_world": [1],
        }

        for key, expected in expected_final.items():
            actual = final.get(key)
            if actual != expected:
                raise RuntimeError(
                    f"Final inventory mismatch for {key}: "
                    f"expected {expected!r}, got {actual!r}"
                )

        if receipt["per_world_completed"] != [True]:
            raise RuntimeError(
                "Final per-world completion flags must be [True]: "
                f"{receipt['per_world_completed']!r}"
            )

        if receipt["step_counts_flat"] != [TRANSITIONS]:
            raise RuntimeError(
                "Final per-world step counts must be [2400]: "
                f"{receipt['step_counts_flat']!r}"
            )

        if step_counts != [TRANSITIONS]:
            raise RuntimeError(
                f"Expected one world at {TRANSITIONS} steps; "
                f"observed {step_counts}"
            )

        receipt["cuda_memory_after"] = {
            "allocated_bytes": torch.cuda.memory_allocated(device),
            "reserved_bytes": torch.cuda.memory_reserved(device),
            "max_allocated_bytes": torch.cuda.max_memory_allocated(device),
            "max_reserved_bytes": torch.cuda.max_memory_reserved(device),
        }

        source_after = a21.source_identity(root)
        receipt["source_identity_after"] = a21.json_safe(source_after)

        if source_after.get("status") != "verified":
            raise RuntimeError(
                "Final A1 source identity did not report status=verified"
            )

        if json.dumps(
            a21.json_safe(source_before), sort_keys=True, default=str
        ) != json.dumps(
            a21.json_safe(source_after), sort_keys=True, default=str
        ):
            raise RuntimeError("A1 source identity changed during the pilot")

        receipt["git_after"] = git_guard(root)

        receipt["status"] = "completed"
        receipt["completed_utc"] = dt.datetime.now(
            dt.timezone.utc
        ).isoformat()
        save()
        return 0

    except BaseException as exc:
        receipt["status"] = (
            "child_deadline" if type(exc).__name__ == "PilotDeadline"
            else "failed"
        )
        receipt["error_type"] = type(exc).__name__
        receipt["error"] = str(exc)
        receipt["traceback"] = traceback.format_exc()
        try:
            save()
        except BaseException:
            pass
        return 1


def parent_main(root, output_dir):
    root = Path(root).resolve()
    output_dir = Path(output_dir).resolve()

    receipt_path = output_dir / "child_receipt.json"
    parent_path = output_dir / "parent_receipt.json"
    stdout_path = output_dir / "child_stdout.txt"
    stderr_path = output_dir / "child_stderr.txt"

    parent = {
        "pilot": "LAWLESS_A22_CUDA_B1N1",
        "measurement_type": "instrumented_correctness_pilot",
        "status": "running",
        "root": str(root),
        "expected_commit": EXPECTED_COMMIT,
        "parent_timeout_seconds": PARENT_LIMIT_SECONDS,
        "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
    }

    try:
        script_path = Path(__file__).resolve()

        if is_inside(script_path, root):
            raise RuntimeError(
                f"Pilot script must be outside checkout: {script_path}"
            )
        if is_inside(output_dir, root):
            raise RuntimeError(
                f"Evidence directory must be outside checkout: {output_dir}"
            )

        output_dir.mkdir(parents=True, exist_ok=True)

        parent["git_before"] = git_guard(root)
        parent["script_path"] = str(script_path)
        parent["script_sha256"] = hashlib.sha256(
            script_path.read_bytes()
        ).hexdigest()

        environment = os.environ.copy()
        old_pythonpath = environment.get("PYTHONPATH", "")
        environment["PYTHONPATH"] = (
            str(root) + (os.pathsep + old_pythonpath if old_pythonpath else "")
        )
        environment["PYTHONUNBUFFERED"] = "1"
        environment["PYTHONDONTWRITEBYTECODE"] = "1"

        command = [
            sys.executable,
            str(script_path),
            "--child",
            "--root",
            str(root),
            "--receipt",
            str(receipt_path),
        ]
        parent["command"] = command

        try:
            completed = subprocess.run(
                command,
                cwd=str(root),
                env=environment,
                capture_output=True,
                text=True,
                timeout=PARENT_LIMIT_SECONDS,
                check=False,
            )
            stdout = completed.stdout or ""
            stderr = completed.stderr or ""
            parent["child_exit_code"] = completed.returncode
            parent["child_timed_out"] = False
        except subprocess.TimeoutExpired as exc:
            stdout = exc.stdout or ""
            stderr = exc.stderr or ""
            if isinstance(stdout, bytes):
                stdout = stdout.decode("utf-8", errors="replace")
            if isinstance(stderr, bytes):
                stderr = stderr.decode("utf-8", errors="replace")
            parent["child_exit_code"] = None
            parent["child_timed_out"] = True
            parent["timeout_seconds"] = PARENT_LIMIT_SECONDS

        stdout_path.write_text(stdout, encoding="utf-8")
        stderr_path.write_text(stderr, encoding="utf-8")

        if receipt_path.exists():
            parent["child_receipt_available"] = True
            try:
                parent["child_status"] = json.loads(
                    receipt_path.read_text(encoding="utf-8")
                ).get("status")
            except Exception as exc:
                parent["child_receipt_read_error"] = str(exc)
        else:
            parent["child_receipt_available"] = False

        try:
            parent["git_after"] = git_guard(root)
            parent["source_checkout_unchanged"] = True
        except BaseException as exc:
            parent["source_checkout_unchanged"] = False
            parent["post_run_git_error"] = str(exc)

        if (
            not parent["child_timed_out"]
            and parent.get("child_exit_code") == 0
            and parent.get("child_status") == "completed"
            and parent.get("source_checkout_unchanged")
        ):
            parent["status"] = "completed"
        elif parent["child_timed_out"]:
            parent["status"] = "parent_timeout"
        else:
            parent["status"] = "failed"

    except BaseException as exc:
        parent["status"] = "parent_failed"
        parent["error_type"] = type(exc).__name__
        parent["error"] = str(exc)
        parent["traceback"] = traceback.format_exc()

    parent["completed_utc"] = dt.datetime.now(
        dt.timezone.utc
    ).isoformat()
    json_write(parent_path, parent)

    # Include the exact executable script and all receipts/logs.
    script_path = Path(__file__).resolve()
    script_copy = output_dir / script_path.name
    if script_path.exists():
        script_copy.write_bytes(script_path.read_bytes())

    archive_path = output_dir.parent / (
        output_dir.name + ".zip"
    )
    with zipfile.ZipFile(
        archive_path, "w", compression=zipfile.ZIP_DEFLATED
    ) as archive:
        for item in sorted(output_dir.rglob("*")):
            if item.is_file():
                archive.write(
                    item,
                    arcname=str(
                        Path(output_dir.name) / item.relative_to(output_dir)
                    ),
                )

    # Hash and encode the completed archive bytes. These recovery values
    # are printed outside the archive, avoiding a self-referential hash.
    archive_bytes = archive_path.read_bytes()
    archive_sha256 = hashlib.sha256(archive_bytes).hexdigest()
    archive_base64 = base64.b64encode(archive_bytes).decode("ascii")

    print(json.dumps(parent, indent=2, sort_keys=True))
    print(f"\nEvidence directory: {output_dir}")
    print(f"Recovery archive: {archive_path}")
    print(f"Recovery archive bytes: {len(archive_bytes)}")
    print(f"Recovery archive SHA256: {archive_sha256}")
    print("BASE64_BEGIN")
    print(archive_base64)
    print("BASE64_END")

    return 0 if parent["status"] == "completed" else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=str(EXPECTED_ROOT))
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--child", action="store_true")
    parser.add_argument("--receipt", default=None)
    args = parser.parse_args()

    if args.child:
        if not args.receipt:
            parser.error("--receipt is required in child mode")
        return child_main(args.root, args.receipt)

    output_dir = args.output_dir or (
        "/content/LAWLESS_A22_CUDA_B1N1_" + utc_stamp()
    )
    return parent_main(args.root, output_dir)


if __name__ == "__main__":
    raise SystemExit(main())
