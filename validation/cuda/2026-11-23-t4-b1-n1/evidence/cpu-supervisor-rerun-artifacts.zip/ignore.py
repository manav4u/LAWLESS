import os,sys,time,signal,subprocess,json
c=subprocess.Popen([sys.executable,'-c',
'import signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(30)'])
open(os.path.join(os.environ['TMPDIR'],'pid'),'w').write(str(c.pid))
signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(30)
