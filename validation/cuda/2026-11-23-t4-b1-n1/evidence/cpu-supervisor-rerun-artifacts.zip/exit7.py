import os,sys,time,signal,subprocess,json
print('EXIT7',flush=True);sys.exit(7)