import os,sys,time,signal,subprocess,json
c=subprocess.Popen([sys.executable,'-c','import time;time.sleep(30)'])
open(os.path.join(os.environ['TMPDIR'],'pid'),'w').write(str(c.pid))
