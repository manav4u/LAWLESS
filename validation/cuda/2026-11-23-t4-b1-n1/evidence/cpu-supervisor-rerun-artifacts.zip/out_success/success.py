import os,sys,time,signal,subprocess,json
print('OUT_MARK',flush=True)
print('ERR_MARK',file=sys.stderr,flush=True)
json.dump({'partial':True},open(os.path.join(os.environ['TMPDIR'],
'partial.json'),'w'))
